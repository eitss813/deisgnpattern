package adapter;

import java.util.Date;

public class Bank {
    String name;
    String pan;
    Date dob;
    String aadhar;
    String type;
    String fname;
}
