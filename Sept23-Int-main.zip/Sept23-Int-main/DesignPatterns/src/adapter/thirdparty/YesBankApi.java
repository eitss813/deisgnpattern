package adapter.thirdparty;

import java.util.Date;


// Adaptee
public class YesBankApi {

    public void registerBankAccount(String type, String fullName, String pan, Date dob, String fname) {

    }


}
