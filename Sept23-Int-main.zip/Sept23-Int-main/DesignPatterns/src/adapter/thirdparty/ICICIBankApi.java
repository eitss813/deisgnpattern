package adapter.thirdparty;

public class ICICIBankApi {
    public void addBankAccount(String name, String aadhar, String PAN) {

    }

}
