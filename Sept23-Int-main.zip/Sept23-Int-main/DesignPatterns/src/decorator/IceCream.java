package decorator;

public interface IceCream {

    int getCost();
    String getDescription();

}
