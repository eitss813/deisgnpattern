package factory;

public interface Button {

    void setText();

    void changeSize(int size);

}
