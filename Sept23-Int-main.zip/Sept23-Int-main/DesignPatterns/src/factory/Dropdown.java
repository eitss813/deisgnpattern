package factory;

public interface Dropdown {

    void addItem();

    void click();
}
