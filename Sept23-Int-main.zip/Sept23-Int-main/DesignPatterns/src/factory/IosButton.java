package factory;

public class IosButton implements Button {
    @Override
    public void setText() {

    }

    @Override
    public void changeSize(int size) {

    }
}
