package factory;

public class AndroidDropdown implements Dropdown{
    @Override
    public void addItem() {

    }

    @Override
    public void click() {

    }
}
