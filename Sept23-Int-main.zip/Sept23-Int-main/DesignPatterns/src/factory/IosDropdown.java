package factory;

public class IosDropdown implements Dropdown{
    @Override
    public void addItem() {

    }

    @Override
    public void click() {

    }
}
