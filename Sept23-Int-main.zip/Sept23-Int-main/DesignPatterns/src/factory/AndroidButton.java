package factory;

public class AndroidButton implements Button{
    @Override
    public void setText() {

    }

    @Override
    public void changeSize(int size) {

    }
}
