package com.example.bookmyshow.models;

public enum SeatType {
    GOLD, SILVER, DIAMOND
}
