package com.example.bookmyshow.models;

public enum ShowSeatStatus {
    OCCUPIED,
    AVAILABLE,
    BLOCKED
}
