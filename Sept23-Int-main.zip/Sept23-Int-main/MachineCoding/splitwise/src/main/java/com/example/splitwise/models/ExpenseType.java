package com.example.splitwise.models;

public enum ExpenseType {
    TRIP,
    HOME,
    SHOPPING,
    TRAVEL
}
