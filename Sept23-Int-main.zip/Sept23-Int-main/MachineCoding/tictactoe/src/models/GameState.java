package models;

public enum GameState {
    DRAW,
    SUCCESS,
    IN_PROGRESS,
    PAUSED,
    INIT
}
