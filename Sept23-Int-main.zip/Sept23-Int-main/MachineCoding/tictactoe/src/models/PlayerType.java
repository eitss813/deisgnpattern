package models;

public enum PlayerType {
    BOT, HUMAN
}
