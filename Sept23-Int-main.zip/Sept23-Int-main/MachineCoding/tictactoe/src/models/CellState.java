package models;

public enum CellState {
    OCCUPIED,
    EMPTY
}
