package strategies.botplaying;

import models.Board;
import models.Cell;

public class MediumBotPlayingStrategy implements BotPlayingStrategy{
    @Override
    public Cell suggestMove(Board board) {
        return null;
    }
}
