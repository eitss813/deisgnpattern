package models;

public enum PaymentType {
    CARD, CASH, UPI
}
