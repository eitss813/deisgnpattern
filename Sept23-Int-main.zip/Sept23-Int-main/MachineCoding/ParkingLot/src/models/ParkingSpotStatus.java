package models;

public enum ParkingSpotStatus {
    OCCUPIED, RESERVED, AVAILABLE
}
