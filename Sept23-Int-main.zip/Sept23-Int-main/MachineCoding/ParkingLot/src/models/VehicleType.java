package models;

public enum VehicleType {
    CAR, BIKE, BUS
}
