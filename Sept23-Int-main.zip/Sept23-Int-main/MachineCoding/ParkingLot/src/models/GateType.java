package models;

public enum GateType {
    ENTRY, EXIT
}
