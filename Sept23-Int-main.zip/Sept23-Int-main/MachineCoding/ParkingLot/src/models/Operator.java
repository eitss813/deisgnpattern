package models;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Operator {
    private String empId;
    private String name;
}
