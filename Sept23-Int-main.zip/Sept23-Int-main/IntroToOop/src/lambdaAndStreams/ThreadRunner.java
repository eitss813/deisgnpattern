package lambdaAndStreams;

public class ThreadRunner implements Runnable{
    @Override
    public void run() {
        System.out.println("I am in a thread");
    }
}
