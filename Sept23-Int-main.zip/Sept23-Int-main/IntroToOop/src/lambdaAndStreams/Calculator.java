package lambdaAndStreams;

public interface Calculator  {

    public int add(int a, int b);

    public int sub(int a, int b);
}
