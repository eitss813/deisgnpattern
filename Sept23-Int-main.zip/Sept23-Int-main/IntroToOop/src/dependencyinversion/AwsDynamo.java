package dependencyinversion;

public class AwsDynamo {


    public void connect() {
        System.out.println("Connecting to AWS");
    }

    public void query() {
        System.out.println("Running query.");
    }

}
