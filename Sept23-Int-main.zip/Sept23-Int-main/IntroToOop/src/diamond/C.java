package diamond;

public interface C extends A{
    void fun();
}
