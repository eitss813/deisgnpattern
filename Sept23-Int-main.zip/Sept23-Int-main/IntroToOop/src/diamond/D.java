package diamond;

public class D implements B, C{


    @Override
    public void fun() {

    }
}
