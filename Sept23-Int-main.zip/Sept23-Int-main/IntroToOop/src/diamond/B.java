package diamond;

public interface B extends A{
    void fun();
}
