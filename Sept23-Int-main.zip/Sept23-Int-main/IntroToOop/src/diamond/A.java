package diamond;

public interface A {
    void fun();
}
