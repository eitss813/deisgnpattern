package inheritance;

public class Main {
    public static void main(String[] args) {
        Instructor instructor = new Instructor();
//        instructor.username = "rahul.grover";
        instructor.id = 1;
        instructor.avgRating = 4.7;
        System.out.println("DEBUG");

    }
}
