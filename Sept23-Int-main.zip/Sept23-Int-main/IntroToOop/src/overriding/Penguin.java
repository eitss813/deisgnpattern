package overriding;

public class Penguin extends Bird{
    void fly() {
        System.out.println("Don't make me fly!!!!! I can't..");
    }
}
