package overriding;

public class Bird {
    void fly() {
        System.out.println("I can fly :) I am a bird");
    }
}
