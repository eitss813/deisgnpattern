package lambdas;

@FunctionalInterface
public interface MathsOperation {
    int operate(int a, int b);
}
