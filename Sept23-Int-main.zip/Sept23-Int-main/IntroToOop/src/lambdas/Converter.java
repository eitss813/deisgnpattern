package lambdas;

public interface Converter {

    void operate(int a);

}
