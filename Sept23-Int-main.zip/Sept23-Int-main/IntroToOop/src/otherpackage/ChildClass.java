package otherpackage;

import intro.Batch;

public class ChildClass extends Batch {

    String getName() {
        return name;
    }
}
