package interfaces;

public interface InvestmentService {
    void invest();
}
