package addersubtractor;

public class Counter {
    int i = 0;
}
