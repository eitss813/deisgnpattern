package correctdependencyinversion;

public interface CloudDb {

    void connect();

    void query();


}
